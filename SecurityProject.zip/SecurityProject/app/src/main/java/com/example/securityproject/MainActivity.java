package com.example.securityproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public Button ec,dc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ec=findViewById(R.id.ec);
        dc=findViewById(R.id.dc);
        ec.setOnClickListener(this);
        dc.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
    switch (v.getId())
    {
        case R.id.ec:
            Intent i = new Intent(MainActivity.this,Encrypt.class);
            startActivity(i);
            break;

        case  R.id.dc:
            Intent j = new Intent(MainActivity.this,Decrypt.class);
            startActivity(j);
            break;
    }


    }
}
