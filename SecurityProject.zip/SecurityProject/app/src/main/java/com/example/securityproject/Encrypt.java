package com.example.securityproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Integer.parseInt;

public class Encrypt extends AppCompatActivity implements View.OnClickListener {
    private EditText ecText, key;
    private Button submit;
    public String msg = "";
    public int i,j;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encrypt);
        ecText = findViewById(R.id.ecText);
        key = findViewById(R.id.key);
        submit = findViewById(R.id.submit);

        submit.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        String s = "",t="";
        int a=0,k=0;
        char c;
        s = ecText.getText().toString();
        k=Integer.parseInt(key.getText().toString());

        do{
            if(k<1)
            {
                Toast.makeText(getApplicationContext(),"PUBLIC KEY MUST NEEDED",Toast.LENGTH_LONG).show();
            }
            else {
                ecText.setText("");
                for (i = 0; i < s.length(); i++) {
                    c = s.charAt(i);
                    a = c + k;
                    c = (char) a;
                    t = String.valueOf(c);
                    msg = ecText.getText().toString() + t;
                    ecText.setText(msg);

                }

                Intent intent = new Intent(Encrypt.this, Decrypt.class);
                intent.putExtra("encryptedText", msg);
                intent.putExtra("encryptedKey",k);
                startActivity(intent);
            }
        }while (k<1);


    }
}
