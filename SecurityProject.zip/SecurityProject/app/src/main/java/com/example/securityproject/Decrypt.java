package com.example.securityproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Decrypt extends AppCompatActivity implements View.OnClickListener {
    private TextView text1,encrypted,dcMsg,keyText,decrypted;
    private Button submit;
    private EditText key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decrypt);

        text1=findViewById(R.id.text1);
        keyText=findViewById(R.id.keyText);
        dcMsg=findViewById(R.id.dcMsg);
        encrypted=findViewById(R.id.encrypted);
        decrypted=findViewById(R.id.decrypted);
        submit=findViewById(R.id.submit);
        key=findViewById(R.id.key);

        submit.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        String s="",t="",message="";
        int a=0;
        char c;
        int k=0,pin=0,j;
        Intent intent = getIntent();
        s = intent.getStringExtra("encryptedText");
        encrypted.setText(s);
        t=intent.getStringExtra("encryptedKey");
        pin=Integer.parseInt(t);

        k=Integer.parseInt(key.getText().toString());

        if(k==pin)
        {
            for (j = 0; j < s.length(); j++)
            {
                c = s.charAt(j);
                a = c - k;
                c = (char) a;
                t = String.valueOf(c);
                message = decrypted.getText().toString() + t;
                decrypted.setText(message);

            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),"PUBLIC KEY MUST NEEDED",Toast.LENGTH_LONG).show();
        }
    }
}
